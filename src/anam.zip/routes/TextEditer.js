//import './App.css';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { useState } from 'react';
import axios from 'axios';

const SERVER_URL = 'http://localhost:8000/api/posting';

function TextEditer() {
    const [Content, setContent] = useState({
        text: '',
        writer: '',
        title: '',
    });

    const getValue = e => {
        const { name, value } = e.target;
        setContent({
            ...Content,
            [name]: value,
        });
    };

    const onSubmitHandler = async () => {
        let today = new Date();
        let time = {
            year: today.getFullYear(), //���� �⵵
            month: today.getMonth() + 1, // ���� ��
            date: today.getDate(), // ���� ��¥
            hours: today.getHours(), //���� �ð�
            minutes: today.getMinutes(), //���� ��
        };

        let timestring = `${time.year}-${time.month}-${time.date}`;

        const title = Content.title;
        const writer = Content.writer;
        const text = Content.text;
        const date = timestring;

        //post ������� ������
        await axios.post(SERVER_URL, { writer, title, text, date });
        window.location.href = '/view';
    };

    return (
        <div className="App">
            <h1>���ǰԽ���</h1>
            <div className="form-wrapper">
                <input
                    className="title-input"
                    type="text"
                    placeholder="������ �Է��ϼ���"
                    onChange={getValue}
                    name="title"
                />
                <input
                    className="writer-input"
                    type="text"
                    placeholder="�ۼ��� �̸�"
                    onChange={getValue}
                    name="writer"
                />
                <CKEditor
                    editor={ClassicEditor}
                    data="<p>������ �Է��ϼ���</p>"
                    onReady={editor => {
                        // You can store the "editor" and use when it is needed.
                        console.log('Editor is ready to use!', editor);
                    }}
                    onChange={(event, editor) => {
                        const data = editor.getData();
                        setContent({
                            ...Content,
                            text: data,
                        });
                    }}
                    onBlur={(event, editor) => {
                        //console.log('Blur.', editor);
                    }}
                    onFocus={(event, editor) => {
                        //#console.log('Focus.', editor);
                    }}
                />
            </div>
            <button className="submit-button" onClick={onSubmitHandler}>
                �ۼ��Ϸ�
            </button>
        </div>
    );
}

export default TextEditer;

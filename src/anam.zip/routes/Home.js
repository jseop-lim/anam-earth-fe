import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { useState, useEffect } from 'react';
import axios from 'axios';
import ReactHtmlParser from 'react-html-parser';
import Writing from '../components/Writing';
import parse from 'html-react-parser';
import '../App.css';

const SERVER_URL = 'http://localhost:8000/api/posting';

function Home() {
    const [todoList, setTodoList] = useState(null);

    // 紐⑤뱺 湲� �떎 諛쏆븘�삤湲�(湲� �궡�슜��� 諛쏆븘�삱 �븘�슂 x)
    const fetchData = async () => {
        const response = await axios.get(SERVER_URL);
        setTodoList(response.data);
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleClick = e => {
        window.location.href = '/editing';
    };

    return (
        <div className="App">
            <h1>嫄댁쓽寃뚯떆�뙋</h1>
            {todoList?.map(todo => (
                <Writing
                    key={todo.posting_id}
                    id={todo.posting_id}
                    title={todo.title}
                    writer={todo.writer}
                    date={todo.date}
                />
            ))}
            <button className="submit-button" onClick={handleClick}>
                �깉湲��벐湲�
            </button>
        </div>
    );
}

export default Home;

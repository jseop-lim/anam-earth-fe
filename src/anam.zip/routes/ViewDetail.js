import { useState, useEffect } from 'react';
import { useParams } from 'react-router';
import axios from 'axios';
import WritingDetail from '../components/WritingDetail';
import Comment from '../components/Comment';
import '../App.css';

function ViewDetail() {
    const [writing, setWriting] = useState(null);
    const [commentList, setCommentList] = useState(null);
    const [newcomment, setNewcomment] = useState({
        text: '',
        writer: '',
    });

    const { id } = useParams();

    const fetchData = async () => {
        const response1 = await axios.get(
            `http://localhost:8000/api/posting/${id}`
        );
        const response2 = await axios.get(
            `http://localhost:8000/api/comment/${id}`
        );
        setWriting(response1.data);
        setCommentList(response2.data);
    };

    const getValue = e => {
        const { name, value } = e.target;
        setNewcomment({
            ...newcomment,
            [name]: value,
        });
    };

    const onSubmitHandler = async () => {
        let today = new Date();
        let time = {
            year: today.getFullYear(), //���� �⵵
            month: today.getMonth() + 1, // ���� ��
            date: today.getDate(), // ���� ��¥
            hours: today.getHours(), //���� �ð�
            minutes: today.getMinutes(), //���� ��
        };

        let timestring = `${time.year}-${time.month}-${time.date}`;

        const posting_id = id;
        const writer = newcomment.writer;
        const text = newcomment.text;
        const date = timestring;

        //post ������� ������
        await axios.post(`http://localhost:8000/api/comment`, {
            posting_id,
            writer,
            text,
            date,
        });
        window.location.href = `/view/${id}`;
    };

    useEffect(() => {
        fetchData();
    }, []);

    return (
        <div className="App">
            <h1>���ǰԽ���</h1>
            {writing ? (
                <WritingDetail
                    id={writing.id}
                    title={writing.title}
                    writer={writing.writer}
                    text={writing.text}
                    date={writing.date}
                />
            ) : (
                <h1>�Խñ� �ε���...</h1>
            )}
            <h2>���</h2>
            <div>
                <div>
                    <input
                        className="comment-writer"
                        type="text"
                        placeholder="�ۼ��� �̸�"
                        onChange={getValue}
                        name="writer"
                    />
                </div>
                <div>
                    <textarea
                        className="commentarea"
                        type="text"
                        placeholder="����� �Է����ּ���"
                        onChange={getValue}
                        name="text"
                    ></textarea>
                </div>
                <div>
                    <button
                        className="comment-button"
                        onClick={onSubmitHandler}
                    >
                        ��۵��
                    </button>
                </div>
            </div>
            {commentList?.map(todo => (
                <Comment
                    key={todo.comment_id}
                    text={todo.text}
                    writer={todo.writer}
                    date={todo.date}
                />
            ))}
        </div>
    );
}

export default ViewDetail;

import React, { useState, useEffect } from 'react';
import ReactMapGL, { NavigationControl } from 'react-map-gl';
import axios from 'axios';
import 'mapbox-gl/dist/mapbox-gl.css';
import './anam.css';
import DaumPostcode from 'react-daum-postcode';

const SERVER_URL = 'http://anam-earth-api.jseoplim.com/map/arcs?level=1';

const AnamMap = () => {
    const [Content, setContent] = useState({
        start: '',
        end: '',
    });

    const getValue = e => {
        const { name, value } = e.target;
        setContent({
            ...Content,
            [name]: value,
        });
    };

    const onSubmitHandler = async () => {
        const start = Content.start;
        const end = Content.end;

        //post 방식으로 보내기
        await axios.post(SERVER_URL, { start, end });
        window.location.href = '/';
    };

    const MAP_TOKEN =
        'pk.eyJ1IjoieXl5eWhwIiwiYSI6ImNsNmJycG00MDFlMGQzY21kNml5ZzNjZHAifQ.D3Y8MmV8mgwBgfbPH2Suvg';
    const [viewport, setViewport] = useState({
        latitude: 37.58613,
        longitude: 127.0288,
        width: '80vw',
        height: '70vh',
        zoom: 14,
    });

    return (
        <div>
            <div className="Mapbox">
                <ReactMapGL
                    style={{ width: '80vw', height: '70vh' }}
                    {...viewport}
                    mapboxAccessToken={MAP_TOKEN}
                    mapStyle="mapbox://styles/mapbox/streets-v11"
                    onMove={evt => setViewport(evt.viewport)}
                >
                    <div className="navi-control">
                        <NavigationControl />
                    </div>
                </ReactMapGL>
            </div>
            <div className="form-wrapper">
                <span
                    style={{
                        fontSize: '20px',
                        fontWeight: 'bold',
                        marginRight: '10px',
                    }}
                >
                    �빊�뮆而삼쭪占�:
                </span>
                <input
                    className="test"
                    type="text"
                    placeholder="�빊�뮆而삼쭪占썹몴占� 占쎌뿯占쎌젾占쎈릭占쎄쉭占쎌뒄."
                    onChange={getValue}
                    name="title"
                />
                <span
                    style={{
                        fontSize: '20px',
                        fontWeight: 'bold',
                        marginRight: '10px',
                    }}
                >
                    占쎈즲筌△뫗占쏙옙:
                </span>
                <input
                    className="test"
                    type="text"
                    placeholder="占쎈즲筌△뫗占쏙옙�몴占� 占쎌뿯占쎌젾占쎈릭占쎄쉭占쎌뒄."
                    onChange={getValue}
                    name="writer"
                />
            </div>

            <div>
                <button className="submit-button" onClick={onSubmitHandler}>
                    작성완료
                </button>
            </div>
        </div>
    );
};
export default AnamMap;

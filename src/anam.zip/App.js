import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'antd/dist/antd.css';
import 'mapbox-gl/dist/mapbox-gl.css';


import Barrier_free_level from './Barrier_free_level';

import CustomLayout from './containers/Layout';
import BoardPage from './components/views/BoardPage/BoardPage';
import AnamMap from './anam';

//��?��?��? components
import TextEditer from './routes/TextEditer';
import Home from './routes/Home';
import ViewDetail from './routes/ViewDetail';

function App() {
    return (
        <Router>
            <Routes>
                <Route
                    exact
                    path="/Barrier_free_level"
                    element={
                        <CustomLayout>
                            <Barrier_free_level />
                        </CustomLayout>
                    }
                />
                <Route
                    exact
                    path="/"
                    element={
                        <CustomLayout>
                            <BoardPage />
                        </CustomLayout>
                    }
                />
                <Route
                    exact
                    path="anam"
                    element={
                        <CustomLayout>
                            <AnamMap />
                        </CustomLayout>
                    }
                />
                <Route path="editing" element={<TextEditer />} />
                <Route path="view" element={<Home />} />
                <Route path="view/:id" element={<ViewDetail />} />
            </Routes>
        </Router>
    );
}

export default App;

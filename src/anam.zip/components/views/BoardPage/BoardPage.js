import React from 'react';
import { Link } from 'react-router-dom';

function BoardPage() {
    return (
        <div>
            <div>
                <h1>Front Pratice</h1>
            </div>
            <div style={{ width: '100px', height: '100px' }}>
                <Link to="/anam">
                    <button>AnamMap</button>
                </Link>
            </div>
            <div id="notice_board" style={{ width: '100px', height: '100px' }}>
                <Link to="/view">
                    <button>notice board!</button>
                </Link>
            </div>
            <span>
                <Link to="/Barrier_free_level">
                    <button>Barrier_free_level</button>
                </Link>
            </span>
        </div>
    );
}
export default BoardPage;
